<?php
require_once 'header.php'
?>

<?php

if(!empty($_POST)){

    $errors = array();

    if(empty($_POST['username']) || !preg_match("/^[a-z0-9_]+$/",$_POST['username'])){
        $errors['username'] = "Votre nom n'est pas valide (alphanumerique)";

    }
    if(empty($_POST['email'])){
    }
}

?>


  <head>
    <meta charset="UTF-8">
   
    <link rel="stylesheet" href="Registre.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="container">
    <div class="title">Inscription</div>
    <div class="content">
      <form action="#">
        <div class="user-details">
          <div class="input-box">
            <span class="details">Nom & Prénom</span>
            <input type="text" placeholder="Entrez votre nom et prénom" required>
          </div>
          <div class="input-box">
            <span class="details">Nom d'usage</span>
            <input type="text" placeholder="Entrez votre nom d'usage" required>
          </div>
          <div class="input-box">
            <span class="details">Serveur</span>
            <input type="text" placeholder="Entrez votre serveur" required>
          </div>
          <div class="input-box">
            <span class="details">Mot de passe </span>
            <input type="text" placeholder="Entrez votre mot de passe" required>
          </div>
          <div class="input-box">
            <span class="details">Confirmation mot passe</span>
            <input type="text" placeholder="Confirmer votre mot de passe" required>
          </div>
          <div class="input-box">
            <span class="details">Role</span>
            <input type="text" placeholder="Définissez votre role" required>
          </div>
        </div>
        <div class="gender-details">
          <input type="radio" name="gender" id="dot-1">
          <input type="radio" name="gender" id="dot-2">
          <input type="radio" name="gender" id="dot-3">
          <span class="gender-title">Genre</span>
          <div class="category">
            <label for="dot-1">
            <span class="dot one"></span>
            <span class="gender">Homme</span>
          </label>
          <label for="dot-2">
            <span class="dot two"></span>
            <span class="gender">Femme</span>
          </label>
          <label for="dot-3">
            
            
            </label>
          </div>
        </div>
        <div class="button">
          <input type="submit" value="S'inscrire">
        </div>
      </form>
    </div>
  </div>

</body>
</html>
