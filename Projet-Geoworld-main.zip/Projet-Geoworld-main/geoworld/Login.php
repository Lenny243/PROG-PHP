<?php
session_start();
/**
 * L'inclusion de ce script déclenche la connexion à la base de données
 *
 * PHP version 7
 *
 * @category  Connexion_DB
 * @package   Application
 * @author    SIO-SLAM <sio@ldv-melun.org>
 * @copyright 2019-2021 SIO-SLAM
 * @license   http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link      https://github.com/sio-melun/geoworld
 */
?>

<?php require_once 'header.php'; ?>

<html lang="en" dir="ltr">
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet"  href="forme.css">
</head>
<body>
	<div class="center">
		<h1>Connexion</h1>
		<form method="post">
			<div class="txt_field">
				<input type="text " required>
				<span></span>
				<label>Identifiant</label>
			  </div>
			  	
			  <div class="txt_field">
				<input type="password" required>
				<span></span>
				<label>Mot de passe</label>
			</div>
			
			<input type="submit" value ="Connexion">
			<div class="signup_link">Pas encore membre ?<a href="Registre.php">Allons-y</a>
			</div>
		</form>
	</div>

</body>
</html>